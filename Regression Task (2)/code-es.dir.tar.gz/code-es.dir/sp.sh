#!/bin/bash


 rm ftm.put*
 rm di.dat sip3.dat r1.dat r2.dat tinit.dat 2df.dat
 rm ttt1
 
 date >> ttt1

 ./di > ftm.put1

 ./si3 > ftm.put2   

 ./r1 > ftm.put3

 ./r2 > ftm.put4

 ./sh1 > ftm.put6

 ./sht > ftm.put6
 
 ./dsp > ftm.put7

  date >> ttt1


#!/bin/bash


##### Generation of theta and phi for disk inclination

./th1 

VAR0=$(<th1.para)
VAR01=$VAR0
VAR0=$(( VAR0 - 1 ))
#echo 'VAR0='$VAR0
### expr is slow 
#VAR01=`expr "$VAR0" - 1`
#echo 'VAR01='$VAR01


VAR1=$(<th1.dat)
VAR2=$(<th2.dat)
VAR3=$(<th0.dat)
VAR4=$(<th01.dat)
VAR5=$'n.dat'
VAR6=0
VAR9=$'nt.dat'
VAR10=$'s0t.dat.m'

array1=($VAR1)
array2=($VAR2)
array3=($VAR3)
array4=($VAR4)
#echo 'VAR1='$VAR1
#echo 'VAR1='${array1[0]}
#echo 'VAR2='$VAR2
#echo 'VAR2='${array2[0]}

PAR0=$'filename'
PAR1=$'v.dat'
PAR2=$'2df.dat.m'
PAR21=$'2dfv.dat.m'
PAR22=$'tout.datv.m'
PAR23=$'2dfv1.dat.m'
PAR3=$'.test'
PAR4=$'../rungct.dir/tout.dat.m'
PAR5=$'../rungct.dir/'
PAR5A=$'../rungct.dir/*'
PAR6=$'ne.dat'

###### File name generation (emerge.para --> o.para)

PF0=$'o.para'
OF0=$'tout.dat.s0.m'
OVF0=$'tout.datv.s0.m'
VDF0=$'2dfv.dat.s0.m'

rm th3.dat
rm th4.dat
rm th5.dat
rm th6.dat

rm ttt1 ftm.put* filename

##### Running simulations

rm $VAR5
rm $VAR9
echo $VAR01 >> $VAR5

### The number of toutl.dat with 7 data points
VAR8=0
rm $PAR6
rm $PAR5A

for i in `seq 0 $VAR0`
do 

### Allocation of each theta and phi for the two galaxies
 rm th3.dat
 rm th4.dat
 rm th5.dat
 rm th6.dat
# echo ${array1[$i]}
 echo  ${array1[$i]} >> th3.dat
 echo  ${array2[$i]} >> th4.dat
 echo  ${array3[$i]} >> th5.dat
 echo  ${array4[$i]} >> th6.dat

### theta and phi change
 ./pth1
 i1=$(( i + 1 ))
 PF1=$PF0$i1
 OF1=$OF0$i1
 OVF1=$OVF0$i1
 VDF1=$VDF0$i1

    echo $i1  >> ttt1

### Run simulations

    cp td7 td6a
    cp td7 td6
    ./mrsf > ftm.put00

    echo $i1 >> ttt1
    date >> ttt1
    rm nstep.dat
    rm tout.dat*
    rm imfs.dat
    rm imfm.dat
    rm ml.dat
    rm ene.dat
    rm sf.dat*
    rm anim.dat
    rm animc.dat
    rm neierror.dat
    rm error.dat
    rm am.dat*
    rm orbit.dat
    rm tmism.dat*
    rm temp.dat*
    rm s0t.dat

    ./emerge1 > ftm.put01

    ./ai1_cuda > ftm.put
    rm  td6 td6a  tinit.dat ftm.mdl icen.para
    VAR7=$(<nstep.dat)
    echo $VAR7 >> $VAR5
    
    date >> ttt1
   
#--- For tout.dat with 7 data point only

#if [ $VAR7 = 7 ]; then

    VAR8=$(( VAR8 +1 ))
#    echo $VAR8

#---- First run    
    rm  s0v.put
    ./s0dat > s0v.put

#    mv s0t.dat $VAR10$VAR8
    mv s0t.dat  $PAR5$VAR10$VAR8

#for j in `seq 1 $VAR7`
for j in `seq $VAR7 $VAR7`
do
    rm  s0v.put1
    mv $PAR1$j  tout.datv
#    ./s0v > s0v.put1
#    ./velr > ftm.put2
    ./veln > ftm.put2
    ./denr > ftm.put3
#    mv 2dfv.dat $PAR21$VAR8$PAR3$j
#    mv 2df.dat $PAR2$VAR8$PAR3$j
#    mv tout.datv $PAR22$VAR8$PAR3$j
    mv 2dfv.dat $PAR21$VAR8
    mv 2dfv1.dat $PAR23$VAR8
    mv 2df.dat $PAR2$VAR8
    mv tout.datv $PAR22$VAR8
    echo $VAR8 $j >> $PAR0
    echo $PAR1$j >> $PAR0
#    echo $PAR2$VAR8$PAR3$j >> $PAR0
    echo $PAR2$VAR8 >> $PAR0
    mv 2df*.dat* $PAR5
#    mv tout.datv* $PAR5
done

#else
#echo $VAR7  >> $PAR6
#fi

   rm v.dat* 
   date >> ttt1

 cp emerge.para $PF1
 mv $PF1 $PAR5
# cp tout.datv $OVF1
# cp 2dfv.dat $VDF1
# mv $PF1 $OVF1 $VDF1 ../runs0t.dir
#   mv tout.dat $PAR4$i

done

echo $VAR8  >> $VAR9
cp  $VAR5  $PAR5
cp  $VAR9  $PAR5
cp  th1.para  $PAR5
cp  th1a.para  $PAR5
cp  denve.dat  $PAR5


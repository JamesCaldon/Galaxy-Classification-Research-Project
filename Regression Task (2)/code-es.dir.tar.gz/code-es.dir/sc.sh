#!/bin/bash


 rm ftm.put*
 rm di.dat pl.dat tinit.dat 2df.dat
 rm ttt1
 
 date >> ttt1

 ./di > ftm.put1

 ./pl > ftm.put2   

 ./sc1 > ftm.put3

 ./dsp > ftm.put7

  date >> ttt1


 

 ./di > ftm.put1

 ./si3 > ftm.put2   

 ./r1 > ftm.put3

 ./r2 > ftm.put4

 ./sh1 > ftm.put6

 ./sht > ftm.put6
 
# ./dsp > ftm.put7


